[Environment]::SetEnvironmentVariable("ASPNETCORE_ENVIRONMENT", "Development", "Machine")
[Environment]::SetEnvironmentVariable("ConnectionString", "ConnectonStringThroughPSandBeansTalk", "Machine")
